<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login');
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null;
    $profileImage = null;

    if (isset($_FILES['profile-pic']) && $_FILES['profile-pic']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['profile-pic']['tmp_name'];
        $fileName = $_FILES['profile-pic']['name'];
        $fileSize = $_FILES['profile-pic']['size'];
        $fileType = $_FILES['profile-pic']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        $allowedfileExtensions = array('jpg', 'gif', 'png', 'jpeg');
        if (in_array($fileExtension, $allowedfileExtensions)) {
            $uploadFileDir = '../uploads/';
            $dest_path = $uploadFileDir . $user_id . '.' . $fileExtension;

            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                $profileImage = $user_id . '.' . $fileExtension;
            }
        }
    }

    $sql = "UPDATE users SET name = ?, profile_image = ?" . ($password ? ", password = ?" : "") . " WHERE id = ?";
    $params = [$username, $profileImage];
    if ($password) {
        $params[] = $password;
    }
    $params[] = $user_id;

    $stmt = $pdo->prepare($sql);
    if ($stmt->execute($params)) {
        header('Location: ../central/my-profile');
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>
