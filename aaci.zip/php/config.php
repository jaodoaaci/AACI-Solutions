<?php
// Definindo os parâmetros de conexão com o banco de dados
$host = '172.233.0.179';   // Endereço do servidor do banco de dados
$db = 'aacidigi_aaci';     // Nome do banco de dados
$user = 'aacidigi_aaci';   // Nome de usuário para conectar ao banco de dados
$pass = 's?Tm2Gw.rTY6';    // Senha para conectar ao banco de dados

// Criando a conexão com o banco de dados
$con = new mysqli($host, $user, $pass, $db);

// Verificando se houve algum erro na conexão
if ($con->connect_error) {
    die('Erro ao conectar ao banco de dados: ' . $con->connect_error);
}
?>
