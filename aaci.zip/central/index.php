<?php
session_start();
require '../php/config.php';
//Verificar se o usuario está logado. Se não, redireciona com Header.
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Central do Usuário</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body, .navbar, .nav-link, .logo {
            font-family: 'Poppins', sans-serif;
        }
        body {
            background-color: #f3e5f5;
        }
        .modal-content {
            background-color: #fff;
        }
    </style>
</head>
<header class="navbar navbar-expand-lg" style="background-color: #6a0dad;">
    <nav class="container d-flex justify-content-between align-items-center py-3">
        <div class="logo fs-4 fw-bold text-white">Olá, <?= htmlspecialchars($user['name']) ?></div>
        <ul class="nav">
            <li class="nav-item"><a href="#home" class="nav-link text-white">Home</a></li>
            <li class="nav-item"><a href="my-profile" class="nav-link text-white">Perfil</a></li>
            <li class="nav-item"><a href="#settings" class="nav-link text-white">Configurações</a></li>
            <li class="nav-item"><a href="chat" class="nav-link text-white">Configurações</a></li>
            <li class="nav-item"><a href="#" id="logout" class="nav-link text-white" data-bs-toggle="modal" data-bs-target="#logoutModal">Logout</a></li>
        </ul>
    </nav>
</header>

    <main class="container mt-5 pt-5">
        <section id="home" class="my-4">
            <div class="text-center">
                <h1>Bem-vindo à Central do Usuário, <?= htmlspecialchars($user['name']) ?>!</h1>
                <p>Aqui você pode gerenciar suas informações pessoais e configurações.</p>
            </div>
        </section>
        <section id="profile" class="my-4">
            <div class="card p-4">
                <h2 class="card-title">Perfil do Usuário</h2>
                <p class="card-text"><strong>Nome:</strong> <?= htmlspecialchars($user['name']) ?></p>
                <p class="card-text"><strong>Email:</strong> <?= htmlspecialchars($user['email']) ?></p>
            </div>
        </section>
        <section id="settings" class="my-4">
            <div class="card p-4 text-center">
                <h2>Saldo Disponível</h2>
                <h3 class="text-success">R$<?= htmlspecialchars($saldo['saldo']) ?>,00</h3>
            </div>
        </section>
    </main>
    <!-- Modal de Confirmação de Logout -->
    <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logoutModalLabel">Confirmação de Logout</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Tem certeza que deseja sair?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <a href="../php/logout.php" class="btn btn-danger">Sim, sair</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../js/central.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const logoutLink = document.getElementById('logout');
            const logoutModal = new bootstrap.Modal(document.getElementById('logout-modal'));
            const confirmLogoutBtn = document.getElementById('confirm-logout');
            const cancelLogoutBtn = document.getElementById('cancel-logout');

            // Abrir modal ao clicar no link de logout
            logoutLink.addEventListener('click', function(event) {
                event.preventDefault();
                logoutModal.show();
            });

            // Fechar modal ao clicar em Cancelar
            cancelLogoutBtn.addEventListener('click', function() {
                logoutModal.hide();
            });

            // Redirecionar ao clicar em Confirmar Logout
            confirmLogoutBtn.addEventListener('click', function() {
                window.location.href = '../php/logout.php';
            });
        });
    </script>
</body>
</html>