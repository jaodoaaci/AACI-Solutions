<?php
session_start();
require '../../php/config.php';
//Verificar se o usuario está logado. Se não, redireciona com Header.
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login');
    exit();
}
//Puxar nome ,email e imagem de usuario
$stmt = $pdo->prepare('SELECT Username, Email, Picture FROM User WHERE id = ?');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();
//Puxar saldo
/*$stmt = $pdo->prepare('SELECT saldo FROM users WHERE id = ?');
$stmt->execute([$_SESSION['user_id']]);
$saldo = $stmt->fetch();*/
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil do Usuário</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts - Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f3e5f5;
        }

        header {
            background-color: #6a0dad;
            color: #fff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .logo {
            font-size: 24px;
            font-weight: bold;
        }

        main {
            padding-top: 100px;
            max-width: 800px;
            margin: auto;
        }

        .section {
            margin-bottom: 40px;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.5s ease-in-out;
        }

        .profile-info img {
            border-radius: 50%;
            border: 2px solid #6a0dad;
            width: 150px;
            height: 150px;
            object-fit: cover;
        }

        button {
            background-color: #6a0dad;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.3s;
            width: 100%;
            margin-top: 20px;
        }

        button:hover {
            background-color: #9c27b0;
            transform: translateY(-3px);
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
    </style>
</head>
<body>
<header class="navbar navbar-expand-lg" style="background-color: #6a0dad;">
    <nav class="container d-flex justify-content-between align-items-center py-3">
        <div class="logo fs-4 fw-bold text-white">Olá, <?= htmlspecialchars($user['Username']) ?></div>
        <ul class="nav">
            <li class="nav-item"><a href="../" class="nav-link text-white">Home</a></li>
            <li class="nav-item"><a href="" class="nav-link text-white">Perfil</a></li>
            <li class="nav-item"><a href="#settings" class="nav-link text-white">Chats Privativos</a></li>
            <li class="nav-item"><a href="#" id="logout" class="nav-link text-white" data-bs-toggle="modal" data-bs-target="#logoutModal">Logout</a></li>
        </ul>
    </nav>
</header>
    <main>
        <section class="section">
            <div class="welcome text-center">
                <h1>Bem-vindo, <?= htmlspecialchars($user['Username']) ?></h1>
            </div>
            <div class="profile-info text-center">
                <img src="../../uploads/<?= htmlspecialchars($user['Picture']) ?>" alt="Imagem de Perfil">
                <p><strong>Nome:</strong> <?= htmlspecialchars($user['User']) ?></p>
                <p><strong>Email:</strong> <?= htmlspecialchars($user['Email']) ?></p>
            </div>
            <div class="settings">
                <h2>Editar Perfil</h2>
                <form action="../../php/upload_profile.php" method="post" enctype="multipart/form-data">
                    <div class="form-group mb-3">
                        <label for="profile-pic">Alterar Imagem de Perfil:</label>
                        <input type="file" id="profile-pic" name="profile-pic" class="form-control">
                    </div>
                    <div class="form-group mb-3">
                        <label for="username">Nome:</label>
                        <input type="text" id="username" name="username" value="<?= htmlspecialchars($user['Username']) ?>" class="form-control">
                    </div>
                    <div class="form-group mb-3">
                        <label for="password">Senha:</label>
                        <input type="password" id="password" name="password" class="form-control">
                    </div>
                    <button type="submit" class="btn" style="background: #6a0dad;color:#fff;">Salvar Alterações</button>
                </form>
            </div>
        </section>
    </main>
 <div class="modal fade" id="logoutModal" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logoutModalLabel">Confirmação de Logout</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Tem certeza que deseja sair?
                </div>
                <div class="modal-footer">
                    <a href="../../php/logout.php" class="btn btn-danger">Sim, sair</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
