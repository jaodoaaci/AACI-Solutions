<?php
// Configurações do banco de dados
$host = 'localhost';  // Servidor do banco de dados
$user = 'aacidigi_aaci'; // Nome de usuário do banco de dados
$password = 's?Tm2Gw.rTY6'; // Senha do banco de dados
$dbname = 'aacidigi_aaci'; // Nome do banco de dados

// Conexão ao banco de dados
$con = mysqli_connect($host, $user, $password, $dbname);

// Verifica se a conexão foi bem-sucedida
?>

