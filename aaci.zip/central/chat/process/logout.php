<?php
    setcookie("ID", NULL, 1);
    setcookie("TOKEN", NULL, 1);
    setcookie("SECURE", NULL, 1);
?>