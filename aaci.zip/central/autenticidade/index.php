<?php
require '../../php/config.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificação de Documentos</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/styles2.css">
    <link rel="stylesheet" href="../../css/modal.css">
</head>
<body>
    <main class="container mt-5">
        <section id="verify-document" class="section">
            <div class="verify">
                <h2 class="mb-4">Verificação de Documentos</h2>
                <form id="verify-form" action="index.php" method="POST" class="mb-4">
                    <div class="form-group">
                        <label for="document-number">Número de Autenticidade:</label>
                        <input type="text" id="document-number" name="document_number" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Verificar</button>
                </form>
                <?php
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $document_number = $_POST['document_number'];
                    $stmt = $pdo->prepare('SELECT * FROM documentos WHERE autenticidade = ?');
                    $stmt->execute([$document_number]);
                    $documents = $stmt->fetchAll();
                    
                    if ($documents) {
                        echo '<h2>Resultado da Verificação</h2>';
                        echo '<table class="table table-striped">';
                        echo '<thead>';
                        echo '<tr>';
                        echo '<th>Assunto do Documento</th>';
                        echo '<th>Nome do Proprietário</th>';
                        echo '<th>Data de Emissão</th>';
                        echo '</tr>';
                        echo '</thead>';
                        echo '<tbody>';
                        foreach ($documents as $document) {
                            echo '<tr>';
                            echo '<td>' . htmlspecialchars($document['assunto']) . '</td>';
                            echo '<td>' . htmlspecialchars($document['nome_proprietario']) . '</td>';
                            echo '<td>' . htmlspecialchars($document['data_emissao']) . '</td>';
                            echo '</tr>';
                        }
                        echo '</tbody>';
                        echo '</table>';
                    } else {
                        echo '<div class="alert alert-danger">Documento não encontrado.</div>';
                    }
                }
                ?>
            </div>
        </section>
    </main>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="../../js/central.js"></script>
</body>
</html>
